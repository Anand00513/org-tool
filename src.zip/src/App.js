import logo from './logo.svg';
import './App.css';
import Search from './Search';

function App() {
  return (
     
        <Search />
    
  );
}

export default App;
