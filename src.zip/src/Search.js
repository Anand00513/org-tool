

import React from 'react';

import { useState, useEffect } from 'react';

function SearchBar () {

    
  const [items, setItems] = useState([]);
  const [filter, setFilter] = useState('');

 
  useEffect(() => {
    fetch("http://localhost:4000/employees",
    {
        headers : { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
         }
      }
    )
      .then(res => res.json())
      .then(
        (result) => {
         
          setItems(result);
        },
     
       
      )
  }, [])
       


return(
    <form action="/" method="get">
        <label htmlFor="header-search">
            <span className="visually-hidden">Search blog posts</span>
        </label>
        <input
            type="text"
            id="header-search"
            placeholder="Search blog posts"
            name="filter" 
            onChange={event => setFilter(event.target.value)}
        />
        <button type="submit">Search</button>

        <div className="title">
        <div>
       
                {items.filter(f => f.includes(filter) || filter === '').map((data, key)=>{
                        return (
                         <div>  
                       

                        <ul key={data.id}>
                        {data.name +"("+data.title+")"}
                          <ul>
                             
                            {data.subordinates[0].name+"("+data.subordinates[0].title+")"}
                            <ul>
                            {data.subordinates[0].subordinates[0].name+"("+data.subordinates[0].subordinates[0].title+")"}
                            </ul> 
                            </ul> 
                            <ul>
                            {data.subordinates[1].name+"("+data.subordinates[1].title+")"}
                            <ul>
                            {data.subordinates[1].subordinates[0].name+"("+data.subordinates[1].subordinates[0].title+")"}
                            <ul>
                            {data.subordinates[1].subordinates[0].subordinates[0].name+"("+data.subordinates[1].subordinates[0].subordinates[0].title+")"}
                            </ul> 
                            </ul> 
                            </ul>
                            <ul>
                            {data.subordinates[1].name+"("+data.subordinates[1].title+")"}
                            </ul>
                        </ul>
                        
                        </div>
                           
                        );
                })} 
                </div>
            </div>
    </form>
)


};
export default SearchBar;